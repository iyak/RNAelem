#!/usr/bin/perl
use File::Basename;
use strict;

require "/rnapromo/lib/load_args.pl";
require "/rnapromo/lib/genie_helpers.pl";
require "/rnapromo/lib/format_number.pl";

my $BG_MOTIF = "/rnapromo/model/motif_bg.tab";
my $BG_MODEL = "/rnapromo/model/model_bg.tab";

if ($ARGV[0] eq "--help")
{
  print STDOUT <DATA>;
  exit;
}

my %args = load_args(\@ARGV);

my $positive_seq = get_arg("positive_seq", "", \%args);
my $positive_struct = get_arg("positive_struct", "", \%args);
my $negative_seq = get_arg("negative_seq", "", \%args);
my $negative_struct = get_arg("negative_struct", "", \%args);

my $fold = get_arg("fold", "200,100", \%args);
my $fold_by = get_arg("fold_by", "Vienna", \%args);
my $subopt = get_arg("subopt", 0.1, \%args);
my $shuffle = get_arg("shuffle", 0, \%args);
my $per_sequence = get_arg("per_sequence", 0, \%args);

my $min = get_arg("min", 15, \%args);
my $max = get_arg("max", 70, \%args);
my $bg_motifs = get_arg("bg_motifs", "$BG_MOTIF", \%args);
my $bg_create = get_arg("bg_create", 0, \%args);
my $bg_factor = get_arg("bg", 0.01, \%args);
my $p_distr = get_arg("p", "b", \%args);
my $position_filter = get_arg("f", "r", \%args);
my $stem = get_arg("stem", 1, \%args);
my $loop = get_arg("loop", 1, \%args);

my $n = get_arg("n", 5, \%args);
my $auc = get_arg("auc", 0, \%args);
my $cv_file = get_arg("cv_file", 0, \%args);
my $bg_file = get_arg("bg_model", "$BG_MODEL", \%args);

my $output_pref = get_arg("output_pref", "", \%args);
my $output_dir = get_arg("output_dir", ".", \%args);

my $q = &get_arg("q", 0, \%args);

my $cmd = "cat tmp_pos_$$.tab | /rnapromo/lib/RNAmotif_finder.pl ";

if (-e $output_dir and ! -d $output_dir )
{
   print STDERR "Error: A file in the same name as the output directory already exists: $output_dir\n";
   exit 1;
}
elsif (! -e $output_dir )
{
   system ("mkdir $output_dir");
}

if ($fold_by ne "Vienna" and $fold_by ne "CONTRAfold")
{
   print STDERR "Error: Requested to fold sequences by an unknown software: $fold_by. Options are Vienna or CONTRAfold.\n";
   exit 1;
}

if ($q != 1) 
{
   print STDERR "Finding Motifs ...\n";
}

if (length($positive_seq) == 0 or ! -e $positive_seq)
{
   print STDERR "Error: Must supply an exisiting positive sequences fasta file (-positive_seq parameter).\n";
   exit 1;
}

if (length($negative_struct) > 0 and length($negative_seq) == 0)
{
   print STDERR "Error: Must supply an exisiting negative sequences fasta file if negative structure are specified (-negative_seq parameter).\n";
   exit 1;
}

my $rc_error;

if (length($positive_struct) > 0)
{
     $rc_error =     &join_struct_to_seq ($positive_seq, $positive_struct, "tmp_pos_$$.tab");
     if (length($rc_error) > 0)
     {
	print STDERR "Error: Error in positive structutre file:\n" .$rc_error . "\n";
	exit 1;
     }
}
else
{
   system ("cat $positive_seq | /rnapromo/lib/fasta2stab.pl > tmp_pos_$$.tab");
   $cmd .= " -fold $fold -subopt $subopt ";
   if ($fold_by eq "CONTRAfold")
   {
      $cmd .= " -contrafold ";
   }
}

if (length($negative_struct) > 0)
{
     $rc_error =     &join_struct_to_seq ($negative_seq, $negative_struct, "tmp_neg_$$.tab");
     if (length($rc_error) > 0)
     {
	print STDERR "Error: Error in negative structutre file:\n" .$rc_error . "\n";
	exit 1;
     }
     $cmd .= " -negative tmp_neg_$$.tab ";
}
elsif (length ($negative_seq) > 0)
{
   system ("cat $negative_seq | /rnapromo/lib/fasta2stab.pl > tmp_neg_$$.tab");
   $cmd .= " -negative tmp_neg_$$.tab ";
}
else
{
   if ($shuffle > 0)
   {
      $cmd .= " -shuffle $shuffle -per_sequence $per_sequence ";
   }
   else
   {
      system ("touch tmp_neg_$$.tab");
      $cmd .= " -negative tmp_neg_$$.tab ";
   }
}


$cmd .=  " -min $min -max $max " . ($bg_create == 1 ? " -bg_create " : " -bg_motifs $bg_motifs ") . " -bg $bg_factor -p $p_distr -f $position_filter -stem $stem -loop $loop -n $n -bg_file $bg_file " .($auc != 0 ? "-auc $auc " . (length($cv_file) > 0 ? " -cv_file $cv_file " : "") : "") . (length($output_dir) > 0 ? "-output_dir $output_dir " : "") . (length($output_pref) > 0 ? "-output_pref $output_pref " : "-output_pref 0 ") ;

print STDERR "$cmd\n";
# my $error_output = ">& /dev/null";
# if ($ENV{"SEGAL_LAB_DEBUG"} == 1)
#   {
#     $error_output = ""
#   }
my $error_output = "";

system ("$cmd > tmp_out_$$ $error_output ");

system ("cut -f 1-2 tmp_out_$$ > $output_dir/${output_pref}auc.tab; rm tmp_out_$$");

if ($q != 1) 
{
   print STDERR "Done.\nProducing Output...\n";
}


if (`wc -l $output_dir/${output_pref}auc.tab | cut -f 1 -d ' '` > 1) {

   my $auc_str = `cat $output_dir/${output_pref}auc.tab | /rnapromo/lib/body.pl 2 -1 `;
   my @auc_rows = split (/\n/, $auc_str);
  
   for (my $i = 1; $i <= $#auc_rows + 1; $i++)
     {
            
	system ("/rnapromo/lib/RNAmodel_plot.pl $output_dir/${output_pref}cm_${i}.tab -output $output_dir/${output_pref}model_cons_${i} -format png $error_output");
	
	system ("cat $output_dir/${output_pref}alignment_${i}.tab | sed 's/^>>/|/g' | tr '\n' '\t' | tr '|' '\n' | /rnapromo/lib/body.pl 2 -1 | cut -f 2- | /rnapromo/lib/modify_column.pl -c 0 -splt_d ':' | /rnapromo/lib/modify_column.pl -c 0 -rmre '^p_' | /rnapromo/lib/modify_column.pl -c 3,4 -ac 1 | /rnapromo/lib/cut.pl -f 1,4,5,3,6,7 | /rnapromo/lib/modify_column.pl -c 4,5 -rmre '-' | sort -k 4nr,4 | /rnapromo/lib/cap.pl 'Seq ID,Start,End,Score,Sequence,Structure' > $output_dir/${output_pref}locs_${i}.xls");
	
	system ("rm $output_dir/${output_pref}scores_${i}.tab $output_dir/${output_pref}cons_${i}.tab $output_dir/${output_pref}alignment_${i}.tab");
     }
  
 } 
elsif ($auc != 0) {
  system ("cat $output_dir/${output_pref}auc.tab");
}
else {
  print "\nNo results\n";
}

system ("rm tmp_pos_$$.tab tmp_neg_$$.tab");


if ($q != 1) 
{
   print STDERR "Done.\n";
}


sub join_struct_to_seq
  {
    my ($seq_fas_file, $struct_tab_file, $output_file) = @_;

    my $not_matched = `cat $seq_fas_file | /rnapromo/lib/fasta2stab.pl | /rnapromo/lib/join.pl - $struct_tab_file -1 1 -2 1 -neg -q | cut -f 1 | tr '\n' '|' | sed 's/|/<br>/g' `;
    if (length($not_matched) > 0) {
      return "Did not supply structure for these sequences:<br>$not_matched";
    }

    $not_matched = `cat $seq_fas_file | /rnapromo/lib/fasta2stab.pl | /rnapromo/lib/join.pl $struct_tab_file - -1 1 -2 1 -neg -q | cut -f 1 | tr '\n' '|' | sed 's/|/<br>/g' `;
    if (length($not_matched) > 0) {
      return "Supplied structure for unknown sequences:<br>$not_matched";
    }

    my $struct_file_error_str = "";
    my $line;
    my @r;
    my $c = 0;
    open (TMP_STRUCT_FILE, "<${struct_tab_file}");

    while ($line = <TMP_STRUCT_FILE>)
      {
	chop $line;
	$line =~ s/\r//g;

	@r = split(/\t/, $line);
	$c++;

	if (length ($line) == 0)
	  {
	    next;
	  }
	elsif ($#r != 2)
	  {
	    $struct_file_error_str .= "line $c:\tWrong number of fields, expecting 3 fields.<br>";
	  } 
	elsif ( ($r[1] =~ tr/[0-9]//) != length($r[1]))
	  {
	    $struct_file_error_str .= "line $c:\tIllegal sequence index: $r[1].<br>";
	  } 
	elsif  (($r[2] =~ tr/[().]//) != length($r[2]))
	  {
	    $struct_file_error_str .= "line $c:\tIllegal structure (expecting these characters: '().'.<br>";
	  }
	elsif (($r[2] =~ tr/\(//) != ($r[2] =~ tr/\)//))
	  {
	    $struct_file_error_str .= "line $c:\tIllegal structure (expecting equal number of '(' and ')'.<br>";
	  }
      }

    close TMP_STRUCT_FILE;

    if (length($struct_file_error_str) > 0)
      {
	return "Error in structure file:<br>$struct_file_error_str";
      }

    system ("cat $struct_tab_file | /rnapromo/lib/merge_columns.pl -d ':' | /rnapromo/lib/stab2length.pl | /rnapromo/lib/modify_column.pl -c 0 -splt_d ':' | /rnapromo/lib/lin.pl | /rnapromo/lib/cut.pl -f 2,1,3,4 | /rnapromo/lib/modify_column.pl -c 3 -ac 2 | /rnapromo/lib/modify_column.pl -c 3 -s 1 > ${output_file}.chr");
    
    system ("cat $seq_fas_file | /rnapromo/lib/fasta2stab.pl | /rnapromo/lib/extract_sequence.pl -f ${output_file}.chr -d -0 | sed 's/  */\t/g' | cut -f 2,4,7 | /rnapromo/lib/join.pl $struct_tab_file - -1 1,2 -2 1,2 -q | /rnapromo/lib/merge_columns.pl -d ':' | /rnapromo/lib/cut.pl -f 1,3,2 > $output_file");

    my $illegal_index = `cat $seq_fas_file | /rnapromo/lib/fasta2stab.pl | /rnapromo/lib/extract_sequence.pl -f ${output_file}.chr -d -0 | /rnapromo/lib/filter.pl -c 1 -e -q | sed 's/  */\t/g' | cut -f 2,4 | tr '\n' '|' | sed 's/|/<br>/g'`;
    
    system ("rm ${output_file}.chr");
    
    if (length($illegal_index) > 0) {
      return "Error in structure file, out of bound index:<br>$illegal_index";
    }
    
    return "";
  }

__DATA__


rnamotifs08_motif_finder.pl <file_name> [options]

  Reads RNA sequences and finds structural motifs in these sequences.


OPTIONS


Input data:
  -positive_seq <file>      Fasta file containing the positive sequences.

  -positive_struct <file>   Optional. Tab delimited file with the structures that should be used on the positive sequences, in this format:
                                <seq id> <index> <structure>

                            Index is 0-based, structure is in bracket format.

  -fold  <split>,<overlap>  Ignored if input structures were given. Use Vienna RNAfold for folding.
                            Fold the sequences in segments of size <split>, with overlap of
                            <overlap> between segments (default: 200,100)
  -fold_by <str>            Fold input sequences by <str> software. Options are Vienna or CONTRAfold (default: Vienna).
  -subopt <num>             Fold the sequence using suboptimal folds withing <num> range of the MFE (default: 0.1, active if -fold is active).

  -negative_seq <file>      Optional. Fasta file containing negative examples.

  -negative_struct <file>   Optional. Tab delimited file with the structures that should be used on the negative sequences (see -positive_struct)

  -shuffle <num>,<split>,<overlap>      Create <num> negative examples from each input sequence (Default = 5),
                            using the same di-nucleotide distribution as the input set.
                            Fold the sequences in segments of size <split>, with overlap of
                            <overlap> between segments.
  -per_sequence             Calculate the di-nucleotide distribution per sequence.

Initialization:
  -min <num>                Minimal motif size (default = 15).
  -max <num>                Maximal motif size (default = 70).
  -bg_motifs <file>         Negative feature set to use (if not specified use default set).
  -bg_create                Use the negative examples to create negative feature set.
  -bg <num>                 Ignore motifs with p-value > <num> (Default = 0.01).
                            The p-value is calculated for the number of times the motif
                            appears in the input set, using the given BG model.
  -p <n|b>                  Use normal or binomial distribution to calculate pvalues (default: binomial).
                            For normal distribution, counts mean and std should be given in the input file.
  -f <l|r|b|a>              Filtering by position (features that always appear as part of another) (default = r)
                               r = Keep the largest feature.
                               l = Keep the smallest feature.
                               b = Keep both largest and smallest feature.
                               a = keep all features.
  -stem <num>               Treat stems with less then <num> difference in length as equal (Default = 1)
  -loop <num>               Treat loops with less then <num> difference in length as equal (Default = 1)

Learning:
  -n <num>                  Learn <num> motifs for the given sequences (default = 5).
  -auc <k>,<n>              Calculate a <k>-fold cross validation AUC score for finding a motif in the given
                            sequences. Select one out of <num> best motifs when calculating AUC score
                            (If parameters are not specified, use k=5, n=1).
                            In this mode no actual motifs are identified.
  -cv_file <file>           Use cv division specified in the given file (default: random division)
                            File format: <id> <number between 1 to k>
  -bg_model <file>          Background model probabilities (if not specified use default set).


Ouput:
  -output_pref <str>        Add the prefix <str> to all output files.
  -output_dir  <str>        Create dir <str> and save all output files in it.


