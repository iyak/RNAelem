#!/usr/bin/perl

# =============================================================================
# Include
# =============================================================================
use strict;
use List::Util 'shuffle';
require "/rnapromo/lib/load_args.pl";
require "/rnapromo/lib/RNAmodel.pl";

# =============================================================================
# Const
# =============================================================================
my $BG_MOTIF = "/rnapromo/model/motif_bg.tab";
my $BG_MODEL = "/rnapromo/model/model_bg.tab";

# =============================================================================
# Main part
# =============================================================================

# reading arguments
if ($ARGV[0] eq "--help") {
  print STDOUT <DATA>;
  exit;
}


my $file_ref;
my $file_name = $ARGV[0];
if (length($file_name) < 1 or $file_name =~ /^-/) {
  $file_ref = \*STDIN;
}
else {
  shift(@ARGV);
  open(FILE, $file_name) or die("Could not open $file_name.\n");
  $file_ref = \*FILE;
}

my %args = load_args(\@ARGV);
my $cm_file = get_arg("cm",0,\%args);
my $best = get_arg("b", 0, \%args);


# ------------------------------------------------
# Input sequences
# ------------------------------------------------
my $sequences = 0;
open(TEST, ">set_$$.tab") or die ("Cannot create file set_$$.tab\n");
while (<$file_ref>) {
    chomp $_;
    my ($id, $seq, $struct) = split("\t", "$_");
    $seq =~ tr/T/U/;

    print TEST "$id\t$seq\t$struct\n";
    $sequences++;
}
close(TEST);

print STDERR "$sequences input sequences\n";
print STDERR "--------------------------------------- \n\n";
match_model($BG_MODEL, "$cm_file", "set_$$.tab", "tmp_output_$$.tab", $best);
print STDERR "--------------------------------------- \n\n";

if ($best) {
  my $output = `cat tmp_output_$$.tab | sed 's/^>>\t/#/g' | tr "\n" "\t" | tr "#" "\n" | sort -k 2 -n -r`;
  print $output;
}
else {
  my $output = `cat tmp_output_$$.tab | grep "^>>" | sort -k 3 -n -r | cut -f 2,3`;
  print $output;
}

print STDERR "Done\n";
#system("/bin/rm set_$$.tab tmp_output_$$.tab");


# -----------------------------------
# help message
# -----------------------------------
__DATA__
rnamotifs08_motif_match.pl <input file>

Input format: <id> <sequence> <structure>
Output format: <id> <score>
output the likelihood score of *all* possible alignments.

  Options:
    -cm <file>          Covariance model to use.
    -b                  Output the best alignment score.
                        Format: <id> <score> <start> <end> <seq> <struct> <model>
